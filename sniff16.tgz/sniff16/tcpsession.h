/*
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Copyright 2014 Marco Lavoie
    marco@marcolavoie.ca
*/
#ifndef TCPSESSION_H
#define TCPSESSION_H

#include <string>

#include "ippacket.h"           // IPPacket
#include "tcpsegment.h"         // TCPSegment

/* TCPSession: class tracking datagrams exchanged within a single TCP session betweenà
 *             two hosts
 *
 * Attributes
 *   sourceId      : key of host having initiated the session (IP:Port)
 *   destinationId : key of host having received the connection request (IP:Port)
 *   state         : current state of the state machine
 *   bytes         : count of data bytes having been exchanged during the session
 */
class TCPSession {
  public:
    TCPSession();                                                // default constructor
    TCPSession(IPPacket &);                                      // parameterized constructor
        
    unsigned int trackState(IPPacket &, bool);                   // TCP session manager
        
    unsigned int getState() const;                               // access to state attribute
    unsigned int getBytes() const;                               // access to bytes attribute
    
    bool terminated() const;                                     // tells if session terminated
        
    static bool getKeys(IPPacket &, string &, string &);         // keys identifying session
        
  private:
    string   sourceId;                                           // key identifying source host
    string   destinationId;                                      // key identifying destination host
        
    unsigned int state;                                          // current session state
    unsigned int bytes;                                          // count of data bytes exchanged in session
};

#endif

