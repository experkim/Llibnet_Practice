/* Classe: TTFTPConData
 * Auteur: Marco Lavoie
 *
 * Classe stockant de l'information sur une connexion TFTP entre un client et un serveur.
 */

#ifndef TFTPCONDATA_H
#define TFTPCONDATA_H

#include <iostream>

using namespace std;

// Classe servant a stocker les infos d'une connexion TFTP.
class TFTPConData {
public:
	// Constructeurs
	TFTPConData();						// constructeur par defaut
	TFTPConData(const char *, int);		// constructeur parametre

	// Accesseur et mutateurs pour l'attribut bytes
	int getBytes() const;				// retourne la valeur dans bytes
	int addBytes(int);					// ajoute la valeur donnee a bytes
	void clearBytes();					// remet bytes a zero

	// Retourne VRAI si l'instance donnee a le meme IP que this.
	bool memeIp(const TFTPConData &) const;

	// Surcharge des operateurs
	bool operator==(const TFTPConData &) const;
	friend ostream & operator<<(ostream &, const TFTPConData &);

private:
	char client_ip[16];		// adresse IP du client sous forme textuelle
	int  client_port;		// port client recevant les datagrammes TFTP
	long bytes;				// nombre d'octets transités via TFTP
};

#endif
