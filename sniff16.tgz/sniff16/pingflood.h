/*
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Copyright 2014 Marco Lavoie
    marco@marcolavoie.ca
*/
#ifndef PINGFLOOD_H
#define PINGFLOOD_H

#include <sstream>             // ostringstream
#include <sys/time.h>          // gettimeofday()
#include <map>                 // STL map

#include "ipaddress.h"         // IPAddress
#include "icmppacket.h"        // ICMPPacket

using namespace std;

/* PingFloodDetection: class applying ping flood detection to provided ICMP echo 
 *                     request packets.
 *
 * Attributes
 *   pingFloods : STL map structure for associating ping echo requests data to
                  targeted IP addresses
 */
class PingFloodDetection {
  /* PingRequestData: class storing ICMP echo request data for one a single 
   *                  targeted IP address.
   *
   * Attributes
   *   cout_ip: counts the number of successive ICMP ping requests received.
   *   sum_delays: sum of the delays (in milliseconds) between successive ICMP ping 
   *               requests received.
   *   time_last_arrival: time (in milliseconds) elapsed since the last ICMP echo
   *                      request was received.
   */
  struct PingRequestData {
    // Parameterized default constructor
    PingRequestData(unsigned int c = 0, unsigned long s = 0, unsigned long t = 0) 
      : count_ip(c), sum_delays(s), time_last_arrival(t) {
    }
    
    unsigned int  count_ip;             // count of received pings
    unsigned long sum_delays;           // sum of delays between successive pings
    unsigned long time_last_arrival;    // time of arrival of latest ping
  };
  
  public:
    bool process_ping(const IPAddress &, const ICMPPacket &);  // core routine for flood detection

  private:
    map<string, PingRequestData> pingFloods;  // dictionary storing ping data for each targeted IP
};
  
  
#endif

