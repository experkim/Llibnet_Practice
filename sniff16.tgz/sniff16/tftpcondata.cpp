/* Classe: TTFTPConData
 * Auteur: Marco Lavoie
 *
 * Implantation de la classe stockant de l'information sur une connexion TFTP entre un
 * client et un serveur.
 */

#ifndef TFTPCONDATA_CPP
#define TFTPCONDATA_CPP

#include <iostream>
#include <cstring>

#include "tftpcondata.h"

using namespace std;

// Constructeur par defaut.
TFTPConData::TFTPConData() {
	bytes = 0;
}

// Constructeur parametre : doit fournir une adresse IP et un port.
TFTPConData::TFTPConData(const char * ip, int port) {
	strcpy(client_ip, ip);
	client_port = port;
	bytes = 0;
}

// Accesseur de l'attribut bytes.
int TFTPConData::getBytes() const {
	return bytes;
}

// Mutateur de l'attribut bytes : ajoute la valeur donnee a l'attribut.
int TFTPConData::addBytes(int b) {
	bytes += b;
	return bytes;
}

// Mutateur de l'attribut bytes.
void TFTPConData::clearBytes() {
	bytes = 0;
}

// Retourne VRAI si l'instance donnee a le meme IP que this.
bool TFTPConData::memeIp(const TFTPConData & cd) const {
	return strcmp(client_ip, cd.client_ip) == 0;
}

// Surcharge de l'operateur relationnel d'egalite (basee sur les attributs
// client_ip et client_port).
bool TFTPConData::operator==(const TFTPConData & cd) const {
	return (memeIp(cd) && client_port == cd.client_port);
}

// Operateur de flux de sortie: affiche les donnees de connexions.
ostream & operator<<(ostream & ostr, const TFTPConData & cd) {
	ostr << "Client " << cd.client_ip << ": " << cd.bytes << " bytes";

	return ostr;
}

#endif
