/*
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Copyright 2014 Marco Lavoie
    marco@marcolavoie.ca
*/
#ifndef PINGFLOOD_CPP
#define PINGFLOOD_CPP

#include "pingflood.h"  // PingFloodDetection

// Process ping requests, returning true if a ping flood is detected for the given target
bool PingFloodDetection::process_ping(const IPAddress & target, const ICMPPacket & icmp) {
  const int tol_delay = 200;      // if delay larger than this (in ms), it's not part of an attack
  const int tol_count = 100;      // minimum number of successive pings for an attack to be considered
  const int tol_size  = 1024;     // minimum payload size (in bytes) for an attack to be considered

  // Make sure it's a ping request
  if (icmp.type() != 8 || icmp.code() != 0)
    return false;
    
  // Is the ping request large enough to be considered as part of an attack?
  if (icmp.length() - icmp.header_length() < tol_size)
    return false;
  
  // Get current time (in milliseconds since January 1, 1970) as time of packet arrival
  timeval t;
  gettimeofday(&t, 0);
  unsigned long time_arrival = t.tv_sec * 1000.0 + t.tv_usec / 1000.0;  

  // Convert target IP address to string to serve as key in map
  ostringstream ostr;
  ostr << target;
  string key = ostr.str();
  
  // Is it the first ping for this target?
  map<string, PingRequestData>::iterator it = pingFloods.find(key);
  if (it == pingFloods.end()) {
    // It's a new target so initialize ping data for it
    PingFloodDetection::PingRequestData data(0, 0, time_arrival);
    
    // Add new data structure to map
    pingFloods[key] = data;
    it = pingFloods.find(key);
  }

  // Update ping data for this target
  it->second.count_ip           = it->second.count_ip + 1;
  it->second.sum_delays        += time_arrival - it->second.time_last_arrival;
  it->second.time_last_arrival  = time_arrival;

  // Compute the mean packet interarrival time for this target
  double mean_time = 1.0 * it->second.sum_delays / it->second.count_ip;

  // Is it an attack? If so, delete data for target (to prevent considering the next 
  // ping request as a new attack) and return true to flag the attack
  bool attack = (it->second.count_ip >= tol_count) && (mean_time < tol_delay);
  if (attack) pingFloods.erase(key);

  return attack;
}

#endif

