/*
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Copyright 2014 Marco Lavoie
    marco@marcolavoie.ca
*/
#ifndef TCPSESSION_CPP
#define TCPSESSION_CPP

#include <sstream>          // ostringstream

#include "tcpsession.h"

// Default constructor
TCPSession::TCPSession() {
  sourceId = destinationId = "";
    
  state = 0;   // initial state
  bytes = 0;   // no data exchanged yet
}

// Parameterized constructor
TCPSession::TCPSession(IPPacket & ip) {
  // Get TCP session keys
  getKeys(ip, sourceId, destinationId);
    
  state = 0;   // initial state
  bytes = 0;   // no data exchanged yet
}

// Machine state processing: transit from one state to next according to given
// IP packet (which must have a TCP segment as payload)
unsigned int TCPSession::trackState(IPPacket & ip, bool debug) {
  // Get TCP session keys
  string src, dst;
  getKeys(ip, src, dst);
    
  // Make sure the datagram is part of the session
  bool considerDatagram = (sourceId == src && destinationId == dst) || 
                          (sourceId == dst && destinationId == src);
  if (!considerDatagram) return state;
    
  // Determine segment direction according to the host that initiated
  // the connection
  bool forward  = (sourceId == src);
  bool backward = !forward;
    
  // Extract transported TCP segment
  TCPSegment tcp = ip.tcp();
    
  // Apply state machine according to segment
  switch (state) {
    case 0:                                // session closed
      // The segment must be SYN from source
      if (tcp.flag_syn() && !tcp.flag_ack() && forward) {
        bytes = 0;                         // reset data bytes count                
        state = 1;                         // waiting for SYN+ACK from destination
                
        if (debug)                         // display debug info on transition
          cout << sourceId << " >>>>> SYN >>>>> " << destinationId << " (open request)" << endl;
      }
           
      break;
            
    case 1:                                // source transmitted a SYN asking to connect
      // The segment must be SYN+ACK from destination
      if (tcp.flag_syn() && tcp.flag_ack() && backward) {
        state = 2;                         // waiting for ACK from source to complete connection
                
        if (debug)                         // display debug info on transition
          cout << sourceId << " <<< SYN+ACK <<< " << destinationId << " (half opened)" << endl;
      }
                
      break;
            
    case 2:                                // destination sent SYN+ACK accepting connection
      // The segment must be ACK from source
      if (!tcp.flag_syn() && tcp.flag_ack() && forward) {
        state = 3;                         // waiting for FIN from source or destination
                
        if (debug)                         // display debug info on transition
          cout << sourceId << " >>>>> ACK >>>>> " << destinationId << " (opened)" << endl;
      }
                
      break;
            
    case 3:                                // connection established
      // The segment must be FIN in either direction
      if (tcp.flag_fin())
        if (forward) {                     // source initiates termination
          state = 4;                       // waiting an ACK or FIN+ACK from destination
                
          if (debug)                       // display debug info on transition
            cout << sourceId << " >>>>> FIN >>>>> " << destinationId << " (close request)" << endl;
        }
        else {                             // destination initiates termination
          state = 7;                       // waiting an ACK or FIN+ACK from source
                
          if (debug)                       // display debug info on transition
            cout << sourceId << " <<<<< FIN <<<<< " << destinationId << " (close request)" << endl;
        }
                
      break;
            
    case 4:                                // destination having received FIN from source
      // The segment should be ACK or FIN+ACK from destination
      if (!tcp.flag_fin() && tcp.flag_ack() && backward) {
        state = 5;                         // waiting for FIN from destination
                
        if (debug)                         // display debug info on transition
          cout << sourceId << " <<<<< ACK <<<<< " << destinationId << " (half closed)" << endl;
      }
      else if (tcp.flag_fin() && tcp.flag_ack() && backward) {
        state = 6;                         // waiting for ACK from source
                
        if (debug)                         // display debug info on transition
          cout << sourceId << " <<< FIN+ACK <<< " << destinationId << " (half closed)" << endl;
      }
                
      break;
            
    case 5:                                // source having received ACK in response to its FIN 
      // The segment must be FIN from destination
      if (tcp.flag_fin() && backward) {
        state = 6;                         // waiting for ACK from source to complete termination

        if (debug)                         // display debug info on transition
          cout << sourceId << " <<<<< FIN <<<<< " << destinationId << " (reverse close request)" << endl;
      }
                
      break;
            
    case 6:                                // source having received FIN or FIN+ACK from destination
      // The segment must be ACK from source
      if (!tcp.flag_fin() && tcp.flag_ack() && forward) {
        state = 10;                        // session closed
                
        if (debug)                         // display debug info on transition
          cout << sourceId << " >>>>> ACK >>>>> " << destinationId << " (closed)" << endl;
      }
                
      break;
            
    case 7:                                // source having received FIN from destination
      // The segment should be ACK or FIN+ACK from source
      if (!tcp.flag_fin() && tcp.flag_ack() && forward) {
        state = 8;                         // waiting for FIN from source
                
        if (debug)                         // display debug info on transition
          cout << sourceId << " >>>>> ACK >>>>> " << destinationId << " (half closed)" << endl;
      }
      else if (tcp.flag_fin() && tcp.flag_ack() && forward) {
        state = 9;                         // waiting for ACK from destination
                
        if (debug)                         // display debug info on transition
          cout << sourceId << " >>> FIN+ACK >>> " << destinationId << " (half closed)" << endl;
      }
                
      break;
            
    case 8:                                // destination having received ACK in response to its FIN 
      // The segment must be FIN from source
      if (tcp.flag_fin() && forward) {
        state = 9;                         // waiting for ACK from destination to complete termination

        if (debug)                         // display debug info on transition
          cout << sourceId << " >>>>> FIN >>>>> " << destinationId << " (reverse close request)" << endl;
      }
                
      break;
            
    case 9:                                // destination having received FIN or FIN+ACK from source
      // The segment must be ACK from destination
      if (!tcp.flag_fin() && tcp.flag_ack() && backward) {
        state = 10;                        // session closed
                
        if (debug)                         // display debug info on transition
          cout << sourceId << " <<<<< ACK <<<<< " << destinationId << " (closed)" << endl;
      }
                
      break;
  }

  // If connection established, update data bytes counter
  if (state == 3)
    bytes += tcp.length() - tcp.header_length();
        
  return state;       // return current state
}

// Returns value of attribute state
unsigned int TCPSession::getState() const {
  return state;
}

// Returns value of attribute bytes
unsigned int TCPSession::getBytes() const {
  return bytes;
}

// Returns true if state machine has reached final state (i.e. session
// terminated)
bool TCPSession::terminated() const {
  return state == 10;
}

// Returns keys identifying both hosts in the TCP connection
bool TCPSession::getKeys(IPPacket& ip, string & src, string & dst) {
  // Make sure the IP packet transports TCP, and get the segment
  TCPSegment tcp = ip.tcp();
  
  // Build keys from IP addresses and associated TCP ports
  ostringstream out;
              
  out << ip.source_ip() << ':' << tcp.source_port(); 
  src = out.str();
              
  out.str("");     // clear the stream
  
  out << ip.destination_ip() << ':' << tcp.destination_port();
  dst = out.str();
}

#endif

