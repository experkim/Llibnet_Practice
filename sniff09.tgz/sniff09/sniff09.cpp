/*
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Copyright 2014 Marco Lavoie
    marco@marcolavoie.ca
*/
#include <iostream>

#include <cstring>             // memset
#include <cstdlib>             // exit
#include <unistd.h>            // getopt()
#include <signal.h>            // Ctrl+C handling
#include <arpa/inet.h>         // struct in_addr

#include <pcap.h>              // libpcap

#include "datagram.h"          // Datagram
#include "ethernetframe.h"     // EthernetFrame
#include "ippacket.h"          // IPPacket
#include "arppacket.h"         // ARPPacket

using namespace std;

pcap_t        *pcap_session = NULL;   // libpcap session handle

char          *strfilter = NULL;      // textual BPF filter
bpf_program    binfilter;             // compiled BPF filter program

pcap_dumper_t *logfile = NULL;        // file descriptor for datagram logging

// Function releasing all resources before ending program execution
void shutdown(int error_code) {
  // Close log file
  if (logfile != NULL)
    pcap_dump_close(logfile);

  // Destroy compiled BPF filter if need be
  if (strfilter != NULL)
      pcap_freecode(&binfilter);

  // Close libpcap session
  if (pcap_session != NULL)
    pcap_close(pcap_session);

  exit(error_code); // we're done!
}

// Ctrl+C interrupt handler
void bypass_sigint(int sig_no) {
  cout << endl << "*** Capture process interrupted by user..." << endl;

  shutdown(0); // we're done!
}

bool show_raw = false;  // deactivate raw display of data captured

// Callback given to pcap_loop() for processing captured datagrams
void process_packet(u_char *user, const struct pcap_pkthdr * h, const u_char * packet) {
  IPPacket ip;
  ARPPacket arp;
  
  cout << "Grabbed " << h->caplen << " bytes (" << static_cast<int>(100.0 * h->caplen / h->len) 
       << "%) of datagram received on " << ctime((const time_t*)&h->ts.tv_sec);
       
  Datagram pkt(packet, h->caplen);        // initialized Datagram instance
  if (show_raw) cout << "---------------- Raw data -----------------" << pkt << endl;

  EthernetFrame ether = pkt.ethernet();   // get EthernetFrame instance from transported data
  cout << "---------- Ethernet frame header ----------" << endl << ether;
  
  // Display payload content according to EtherType
  switch (ether.ether_type()) {
    case EthernetFrame::et_IPv4 :         // get IPPacket instance from transported data
      ip = ether.ip4();
      cout << "-------- IP packet header --------" << endl << ip;
      break;

    case EthernetFrame::et_ARP :          // get ARPPacket instance from transported data
      arp = ether.arp();
      cout << "-------- ARP packet header --------" << endl << arp;
      break;
  }
      
  cout << endl << flush;

  // Log datagram if required
  if (user != NULL)
    pcap_dump(user, h, packet);
}

// Sniffer's main program: add ARP packet analysis
int main(int argc, char *argv[]) {
  char *device = NULL;            // device to sniff
  char  argch;                    // to manage command line arguments
  char  errbuf[PCAP_ERRBUF_SIZE]; // to handle libpcap error messages
  int   siz     = 1518,           // max number of bytes captured for each datagram
        promisc = 0,              // deactive promiscuous mode
        cnt     = -1;             // capture indefinitely
  char *wlogfname = NULL,         // filename where to log captured datagrams
       *rlogfname = NULL;         // filename from which to read logged datagrams

  // Install Ctrl+C handler
  struct sigaction sa, osa;
  memset(&sa, 0, sizeof(sa));
  sa.sa_handler = &bypass_sigint;
  sigaction(SIGINT, &sa, &osa);

  // Process command line arguments
  while ((argch = getopt(argc, argv, "hprd:f:i:l:n:")) != EOF)
    switch (argch) {
      case 'd':           // device name
        device = optarg;
        break;

      case 'f':           // BPF filter
        strfilter = optarg;
        break;

      case 'h':           // show help info
        cout << "Usage: sniff [-d XXX -h]" << endl;
        cout << " -d XXX : device to capture from, where XXX is device name (ex: eth0)." << endl;
        cout << " -f 'filter' : filter captures according to BPF expression (ex: 'ip or arp')." << endl;
        cout << " -h : show this information." << endl;
        cout << " -i file : read datagrams from given file instead of a device." << endl;
        cout << " -l file : log captured datagrams in given file." << endl;
        cout << " -n : number of datagrams to capture." << endl;
        cout << " -p : activate promiscuous capture mode." << endl;
        cout << " -r : activate raw display of captured data." << endl;

        // Exit if only argument is -h
        if (argc == 2) return 0;
        break;

      case 'i':           // filename from which to read logged datagrams
        rlogfname = optarg;
        break;

      case 'l':           // filename where to log captured datagrams
        wlogfname = optarg;
        break;

      case 'n':           // number of datagrams to capture
        cnt = atoi(optarg);
        break;
        
      case 'p':           // active promiscuous mode
        promisc = 1;
        break;
        
      case 'r':           // active raw display of captured data
        show_raw = 1;
        break;
    }

  // Options -d and -i are mutually exclusives
  if (device != NULL && rlogfname != NULL) {
      cerr << "error - options -d and -i are mutually exclusives" << endl;
      return -7;
  }

  // Identify device to use
  if (rlogfname == NULL && device == NULL)
    if ((device = pcap_lookupdev(errbuf)) == NULL) {
      cerr << "error - " << errbuf << endl;
      return -2;
    }
  
  if (rlogfname != NULL)
    cout << "input file = " << rlogfname << endl;
  else
    cout << "device = " << device << (promisc ? " (promiscuous)" : "") << endl;

  // Extract IP information for network connected to device
  bpf_u_int32 netp,  // ip address of network
              maskp; // network mask

  // If capturing from device, display its attributes
  if (rlogfname == NULL) {
    if ((pcap_lookupnet(device, &netp, &maskp, errbuf)) == -1) {
      cerr << "error - " << errbuf << endl;
      return -3;
    }

    // Translate ip address into textual form for display
    struct  in_addr addr;
    char   *net;
    addr.s_addr = netp;
    if ((net = inet_ntoa(addr)) == NULL)
      cerr << "error - inet_ntoa() failed" << endl;
    else
      cout << "network ip = " << net << endl;

    // Translate network mask into textual form for display
    char *mask;
    addr.s_addr = maskp;
    if ((mask = inet_ntoa(addr)) == NULL)
      cerr << "error - inet_ntoa() failed" << endl;
    else
      cout << "network mask = " << mask << endl;
  }

  // Open a libpcap capture session
  if (rlogfname == NULL) {
    // Session linked to the device
    pcap_session = pcap_open_live(device, siz, promisc, 1000, errbuf);
    if (pcap_session == NULL) {
      cerr << "error - pcap_open_live() failed (" << errbuf << ")" << endl;
      return -4;
    }
  }
  else {
    // Session linked to the log file
    pcap_session = pcap_open_offline(rlogfname, errbuf);
    if (pcap_session == NULL) {
      cerr << "error - pcap_open_offline() failed (" << errbuf << ")" << endl;
      return -8;
    }
  }

  // Compile BPF filter expression into program if one provided
  if (strfilter != NULL) {
    // Compile filter expression
    if (pcap_compile(pcap_session, &binfilter, strfilter, 1, maskp) < 0) {
      cerr << "error - pcap_compile() failed (" << pcap_geterr(pcap_session) << ")" << endl;
      shutdown(-5);    // Cleanup and quit
    }

    // Install compiled filter
    if (pcap_setfilter(pcap_session, &binfilter) < 0) {
      cerr << "error - pcap_setfilter() failed (" << pcap_geterr(pcap_session) << ")" << endl;
      shutdown(-6);    // Cleanup and quit
    }
    
    cout << "BPF filter = " << strfilter << endl;    // display applied filter
  }

  // If need be, open file where captured datagrams are ro be logged
  if (wlogfname != NULL)
    if ((logfile = pcap_dump_open(pcap_session, wlogfname)) == NULL) {
      cerr << "error - pcap_dump_open() failed (" << pcap_geterr(pcap_session) << ")" << endl;
      shutdown(-9);    // Cleanup and quit
  }
  
  // Start capturing...
  pcap_loop(pcap_session, cnt, process_packet, (u_char *)logfile);

  // Close libpcap session
  pcap_close(pcap_session);

  shutdown(0);
}
